/**
 */
package hotelbook;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>User</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hotelbook.HotelbookPackage#getUser()
 * @model
 * @generated
 */
public interface User extends Book {
} // User
