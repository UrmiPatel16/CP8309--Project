/**
 */
package hotelbook.impl;

import hotelbook.Basic;
import hotelbook.HotelbookPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Basic</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BasicImpl extends RoomImpl implements Basic {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BasicImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return HotelbookPackage.Literals.BASIC;
	}

} //BasicImpl
