/**
 */
package hotelbook.impl;

import hotelbook.HotelbookPackage;
import hotelbook.Room;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RoomImpl extends BookImpl implements Room {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoomImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return HotelbookPackage.Literals.ROOM;
	}

} //RoomImpl
