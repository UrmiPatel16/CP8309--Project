/**
 */
package hotelbook;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hotel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link hotelbook.Hotel#getID <em>ID</em>}</li>
 * </ul>
 *
 * @see hotelbook.HotelbookPackage#getHotel()
 * @model
 * @generated
 */
public interface Hotel extends Book {

	/**
	 * Returns the value of the '<em><b>ID</b></em>' attribute.
	 * The default value is <code>"10"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>ID</em>' attribute.
	 * @see #setID(int)
	 * @see hotelbook.HotelbookPackage#getHotel_ID()
	 * @model default="10"
	 * @generated
	 */
	int getID();

	/**
	 * Sets the value of the '{@link hotelbook.Hotel#getID <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>ID</em>' attribute.
	 * @see #getID()
	 * @generated
	 */
	void setID(int value);
} // Hotel
