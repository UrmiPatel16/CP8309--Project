/**
 */
package hotelbook;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Basic</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hotelbook.HotelbookPackage#getBasic()
 * @model
 * @generated
 */
public interface Basic extends Room {
} // Basic
