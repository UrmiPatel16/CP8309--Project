/**
 */
package hotelbook;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hotelbook.HotelbookPackage#getRoom()
 * @model
 * @generated
 */
public interface Room extends Book {
} // Room
