/**
 */
package hotelbook;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Royal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hotelbook.HotelbookPackage#getRoyal()
 * @model
 * @generated
 */
public interface Royal extends Room {
} // Royal
