package org.xtext.example.hotelbooking.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.hotelbooking.services.HotelbookingGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalHotelbookingParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'User'", "'stop'", "'select->'", "'Hotel'", "'Room->'", "'RoyalRoom'", "'BasicRoom'", "'End'"
    };
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_STRING=4;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int RULE_INT=6;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;

    // delegates
    // delegators


        public InternalHotelbookingParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalHotelbookingParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalHotelbookingParser.tokenNames; }
    public String getGrammarFileName() { return "InternalHotelbooking.g"; }



     	private HotelbookingGrammarAccess grammarAccess;

        public InternalHotelbookingParser(TokenStream input, HotelbookingGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected HotelbookingGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalHotelbooking.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalHotelbooking.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalHotelbooking.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalHotelbooking.g:71:1: ruleModel returns [EObject current=null] : ( (lv_book_0_0= ruleBook ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_book_0_0 = null;



        	enterRule();

        try {
            // InternalHotelbooking.g:77:2: ( ( (lv_book_0_0= ruleBook ) )* )
            // InternalHotelbooking.g:78:2: ( (lv_book_0_0= ruleBook ) )*
            {
            // InternalHotelbooking.g:78:2: ( (lv_book_0_0= ruleBook ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalHotelbooking.g:79:3: (lv_book_0_0= ruleBook )
            	    {
            	    // InternalHotelbooking.g:79:3: (lv_book_0_0= ruleBook )
            	    // InternalHotelbooking.g:80:4: lv_book_0_0= ruleBook
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getBookBookParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_book_0_0=ruleBook();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"book",
            	    					lv_book_0_0,
            	    					"org.xtext.example.hotelbooking.Hotelbooking.Book");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleBook"
    // InternalHotelbooking.g:100:1: entryRuleBook returns [EObject current=null] : iv_ruleBook= ruleBook EOF ;
    public final EObject entryRuleBook() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBook = null;


        try {
            // InternalHotelbooking.g:100:45: (iv_ruleBook= ruleBook EOF )
            // InternalHotelbooking.g:101:2: iv_ruleBook= ruleBook EOF
            {
             newCompositeNode(grammarAccess.getBookRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBook=ruleBook();

            state._fsp--;

             current =iv_ruleBook; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBook"


    // $ANTLR start "ruleBook"
    // InternalHotelbooking.g:107:1: ruleBook returns [EObject current=null] : this_User_0= ruleUser ;
    public final EObject ruleBook() throws RecognitionException {
        EObject current = null;

        EObject this_User_0 = null;



        	enterRule();

        try {
            // InternalHotelbooking.g:113:2: (this_User_0= ruleUser )
            // InternalHotelbooking.g:114:2: this_User_0= ruleUser
            {

            		newCompositeNode(grammarAccess.getBookAccess().getUserParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_User_0=ruleUser();

            state._fsp--;


            		current = this_User_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBook"


    // $ANTLR start "entryRuleUser"
    // InternalHotelbooking.g:125:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalHotelbooking.g:125:45: (iv_ruleUser= ruleUser EOF )
            // InternalHotelbooking.g:126:2: iv_ruleUser= ruleUser EOF
            {
             newCompositeNode(grammarAccess.getUserRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;

             current =iv_ruleUser; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalHotelbooking.g:132:1: ruleUser returns [EObject current=null] : (otherlv_0= 'User' ( (lv_username_1_0= RULE_STRING ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_hotel_5_0= ruleHotel ) ) ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_username_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        EObject lv_hotel_5_0 = null;



        	enterRule();

        try {
            // InternalHotelbooking.g:138:2: ( (otherlv_0= 'User' ( (lv_username_1_0= RULE_STRING ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_hotel_5_0= ruleHotel ) ) ) )
            // InternalHotelbooking.g:139:2: (otherlv_0= 'User' ( (lv_username_1_0= RULE_STRING ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_hotel_5_0= ruleHotel ) ) )
            {
            // InternalHotelbooking.g:139:2: (otherlv_0= 'User' ( (lv_username_1_0= RULE_STRING ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_hotel_5_0= ruleHotel ) ) )
            // InternalHotelbooking.g:140:3: otherlv_0= 'User' ( (lv_username_1_0= RULE_STRING ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_hotel_5_0= ruleHotel ) )
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getUserKeyword_0());
            		
            // InternalHotelbooking.g:144:3: ( (lv_username_1_0= RULE_STRING ) )
            // InternalHotelbooking.g:145:4: (lv_username_1_0= RULE_STRING )
            {
            // InternalHotelbooking.g:145:4: (lv_username_1_0= RULE_STRING )
            // InternalHotelbooking.g:146:5: lv_username_1_0= RULE_STRING
            {
            lv_username_1_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_username_1_0, grammarAccess.getUserAccess().getUsernameSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"username",
            						lv_username_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalHotelbooking.g:162:3: (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==12) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalHotelbooking.g:163:4: otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,12,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getUserAccess().getStopKeyword_2_0());
                    			
                    // InternalHotelbooking.g:167:4: ( (otherlv_3= RULE_ID ) )
                    // InternalHotelbooking.g:168:5: (otherlv_3= RULE_ID )
                    {
                    // InternalHotelbooking.g:168:5: (otherlv_3= RULE_ID )
                    // InternalHotelbooking.g:169:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUserRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_7); 

                    						newLeafNode(otherlv_3, grammarAccess.getUserAccess().getSuperTypeUserCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,13,FOLLOW_8); 

            			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getSelectKeyword_3());
            		
            // InternalHotelbooking.g:185:3: ( (lv_hotel_5_0= ruleHotel ) )
            // InternalHotelbooking.g:186:4: (lv_hotel_5_0= ruleHotel )
            {
            // InternalHotelbooking.g:186:4: (lv_hotel_5_0= ruleHotel )
            // InternalHotelbooking.g:187:5: lv_hotel_5_0= ruleHotel
            {

            					newCompositeNode(grammarAccess.getUserAccess().getHotelHotelParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_hotel_5_0=ruleHotel();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getUserRule());
            					}
            					add(
            						current,
            						"hotel",
            						lv_hotel_5_0,
            						"org.xtext.example.hotelbooking.Hotelbooking.Hotel");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleHotel"
    // InternalHotelbooking.g:208:1: entryRuleHotel returns [EObject current=null] : iv_ruleHotel= ruleHotel EOF ;
    public final EObject entryRuleHotel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHotel = null;


        try {
            // InternalHotelbooking.g:208:46: (iv_ruleHotel= ruleHotel EOF )
            // InternalHotelbooking.g:209:2: iv_ruleHotel= ruleHotel EOF
            {
             newCompositeNode(grammarAccess.getHotelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHotel=ruleHotel();

            state._fsp--;

             current =iv_ruleHotel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHotel"


    // $ANTLR start "ruleHotel"
    // InternalHotelbooking.g:215:1: ruleHotel returns [EObject current=null] : (otherlv_0= 'Hotel' ( (lv_idnumber_1_0= RULE_INT ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_room_5_0= ruleRoom ) ) ) ;
    public final EObject ruleHotel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_idnumber_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        EObject lv_room_5_0 = null;



        	enterRule();

        try {
            // InternalHotelbooking.g:221:2: ( (otherlv_0= 'Hotel' ( (lv_idnumber_1_0= RULE_INT ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_room_5_0= ruleRoom ) ) ) )
            // InternalHotelbooking.g:222:2: (otherlv_0= 'Hotel' ( (lv_idnumber_1_0= RULE_INT ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_room_5_0= ruleRoom ) ) )
            {
            // InternalHotelbooking.g:222:2: (otherlv_0= 'Hotel' ( (lv_idnumber_1_0= RULE_INT ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_room_5_0= ruleRoom ) ) )
            // InternalHotelbooking.g:223:3: otherlv_0= 'Hotel' ( (lv_idnumber_1_0= RULE_INT ) ) (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )? otherlv_4= 'select->' ( (lv_room_5_0= ruleRoom ) )
            {
            otherlv_0=(Token)match(input,14,FOLLOW_9); 

            			newLeafNode(otherlv_0, grammarAccess.getHotelAccess().getHotelKeyword_0());
            		
            // InternalHotelbooking.g:227:3: ( (lv_idnumber_1_0= RULE_INT ) )
            // InternalHotelbooking.g:228:4: (lv_idnumber_1_0= RULE_INT )
            {
            // InternalHotelbooking.g:228:4: (lv_idnumber_1_0= RULE_INT )
            // InternalHotelbooking.g:229:5: lv_idnumber_1_0= RULE_INT
            {
            lv_idnumber_1_0=(Token)match(input,RULE_INT,FOLLOW_5); 

            					newLeafNode(lv_idnumber_1_0, grammarAccess.getHotelAccess().getIdnumberINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getHotelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"idnumber",
            						lv_idnumber_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalHotelbooking.g:245:3: (otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==12) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalHotelbooking.g:246:4: otherlv_2= 'stop' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,12,FOLLOW_6); 

                    				newLeafNode(otherlv_2, grammarAccess.getHotelAccess().getStopKeyword_2_0());
                    			
                    // InternalHotelbooking.g:250:4: ( (otherlv_3= RULE_ID ) )
                    // InternalHotelbooking.g:251:5: (otherlv_3= RULE_ID )
                    {
                    // InternalHotelbooking.g:251:5: (otherlv_3= RULE_ID )
                    // InternalHotelbooking.g:252:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getHotelRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_7); 

                    						newLeafNode(otherlv_3, grammarAccess.getHotelAccess().getSuperTypeHotelCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,13,FOLLOW_10); 

            			newLeafNode(otherlv_4, grammarAccess.getHotelAccess().getSelectKeyword_3());
            		
            // InternalHotelbooking.g:268:3: ( (lv_room_5_0= ruleRoom ) )
            // InternalHotelbooking.g:269:4: (lv_room_5_0= ruleRoom )
            {
            // InternalHotelbooking.g:269:4: (lv_room_5_0= ruleRoom )
            // InternalHotelbooking.g:270:5: lv_room_5_0= ruleRoom
            {

            					newCompositeNode(grammarAccess.getHotelAccess().getRoomRoomParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_room_5_0=ruleRoom();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getHotelRule());
            					}
            					add(
            						current,
            						"room",
            						lv_room_5_0,
            						"org.xtext.example.hotelbooking.Hotelbooking.Room");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHotel"


    // $ANTLR start "entryRuleRoom"
    // InternalHotelbooking.g:291:1: entryRuleRoom returns [EObject current=null] : iv_ruleRoom= ruleRoom EOF ;
    public final EObject entryRuleRoom() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRoom = null;


        try {
            // InternalHotelbooking.g:291:45: (iv_ruleRoom= ruleRoom EOF )
            // InternalHotelbooking.g:292:2: iv_ruleRoom= ruleRoom EOF
            {
             newCompositeNode(grammarAccess.getRoomRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRoom=ruleRoom();

            state._fsp--;

             current =iv_ruleRoom; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRoom"


    // $ANTLR start "ruleRoom"
    // InternalHotelbooking.g:298:1: ruleRoom returns [EObject current=null] : (otherlv_0= 'Room->' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'RoyalRoom' | otherlv_3= 'BasicRoom' ) otherlv_4= 'End' ) ;
    public final EObject ruleRoom() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalHotelbooking.g:304:2: ( (otherlv_0= 'Room->' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'RoyalRoom' | otherlv_3= 'BasicRoom' ) otherlv_4= 'End' ) )
            // InternalHotelbooking.g:305:2: (otherlv_0= 'Room->' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'RoyalRoom' | otherlv_3= 'BasicRoom' ) otherlv_4= 'End' )
            {
            // InternalHotelbooking.g:305:2: (otherlv_0= 'Room->' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'RoyalRoom' | otherlv_3= 'BasicRoom' ) otherlv_4= 'End' )
            // InternalHotelbooking.g:306:3: otherlv_0= 'Room->' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'RoyalRoom' | otherlv_3= 'BasicRoom' ) otherlv_4= 'End'
            {
            otherlv_0=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getRoomAccess().getRoomKeyword_0());
            		
            // InternalHotelbooking.g:310:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalHotelbooking.g:311:4: (lv_name_1_0= RULE_ID )
            {
            // InternalHotelbooking.g:311:4: (lv_name_1_0= RULE_ID )
            // InternalHotelbooking.g:312:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(lv_name_1_0, grammarAccess.getRoomAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRoomRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalHotelbooking.g:328:3: (otherlv_2= 'RoyalRoom' | otherlv_3= 'BasicRoom' )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==16) ) {
                alt4=1;
            }
            else if ( (LA4_0==17) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalHotelbooking.g:329:4: otherlv_2= 'RoyalRoom'
                    {
                    otherlv_2=(Token)match(input,16,FOLLOW_12); 

                    				newLeafNode(otherlv_2, grammarAccess.getRoomAccess().getRoyalRoomKeyword_2_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalHotelbooking.g:334:4: otherlv_3= 'BasicRoom'
                    {
                    otherlv_3=(Token)match(input,17,FOLLOW_12); 

                    				newLeafNode(otherlv_3, grammarAccess.getRoomAccess().getBasicRoomKeyword_2_1());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getRoomAccess().getEndKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRoom"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000003000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000040000L});

}